'use client'

import { motion } from 'framer-motion'
import { Server, Database, Cpu, Globe, Shield, Network, HardDrive, Zap } from 'lucide-react'
import { useEffect, useState } from 'react'
import { getTechnicalSpecsContent, TechnicalSpecsContent } from '@/lib/admin'

const iconMap: Record<string, any> = {
  server: Server,
  database: Database,
  cpu: Cpu,
  globe: Globe,
  shield: Shield,
  network: Network,
  'hard-drive': HardDrive,
  zap: Zap
}

export default function TechnicalSpecs() {
  const [content, setContent] = useState<TechnicalSpecsContent>({ title: "", subtitle: "", techStack: [], systemRequirements: [], supportedInverters: [], architecture: [], networkPorts: [] })

  useEffect(() => {
    getTechnicalSpecsContent().then(setContent)
  }, [])


  const enabledTechStack = content.techStack.filter(stack => stack.enabled)
  const enabledInverters = content.supportedInverters.filter(inv => inv.enabled)

  return (
    <section id="technical-specs" className="section-padding bg-dark">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="heading-2 mb-6" dangerouslySetInnerHTML={{ __html: content.title }} />
          <p className="body-large text-text-secondary max-w-4xl mx-auto px-4">
            {content.subtitle}
          </p>
        </motion.div>

        {/* Technology Stack */}
        <div className="mb-20">
          <h3 className="heading-3 text-center mb-12">
            Technology <span className="text-primary">Stack</span>
          </h3>
          
          <div className="grid-auto-fit">
            {enabledTechStack.map((stack, index) => {
              const Icon = iconMap[stack.icon] || Server
              return (
                <motion.div
                  key={stack.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="card-interactive"
                >
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="bg-primary/10 border border-primary/20 rounded-2xl p-3 flex-shrink-0">
                      <Icon className="text-primary" size={24} />
                    </div>
                    <h4 className="heading-4">{stack.category}</h4>
                  </div>
                  
                  <ul className="space-y-4">
                    {stack.technologies.map((tech, techIndex) => (
                      <li key={techIndex} className="border-l-2 border-primary/30 pl-4 hover:border-primary/60 transition-colors">
                        <div className="font-semibold body-base text-text-primary">{tech.name}</div>
                        <div className="body-small text-text-secondary mt-1">{tech.description}</div>
                        <div className="caption text-primary mt-2 font-medium">{tech.version}</div>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              )
            })}
          </div>
        </div>

        {/* System Requirements */}
        <div className="mb-20">
          <h3 className="heading-3 text-center mb-12">
            System <span className="text-primary">Requirements</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {content.systemRequirements.map((req, index) => (
              <motion.div
                key={req.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`card ${index === 1 ? 'border-primary/40 shadow-glow' : ''}`}
              >
                <h4 className="heading-4 mb-6 text-center">{req.platform}</h4>
                <ul className="space-y-4">
                  {req.specs.map((spec, specIndex) => (
                    <li key={specIndex} className="flex justify-between items-center body-base">
                      <span className="text-text-secondary">{spec.label}</span>
                      <span className="font-semibold text-primary text-right">{spec.value}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Supported Inverters */}
        <div className="mb-20">
          <h3 className="heading-3 text-center mb-12">
            Supported <span className="text-primary">Inverters</span>
          </h3>
          
          <div className="grid-auto-fit">
            {enabledInverters.map((inverter, index) => (
              <motion.div
                key={inverter.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="card-interactive"
              >
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-4">
                  <div className="mb-2 sm:mb-0">
                    <h4 className="heading-4 mb-2">{inverter.brand}</h4>
                    <p className="body-small text-text-secondary">{inverter.models}</p>
                  </div>
                  <span className={`self-start ${
                    inverter.status === 'Full Support' ? 'status-success' :
                    inverter.status === 'Beta' ? 'status-warning' :
                    'status-info'
                  }`}>
                    {inverter.status}
                  </span>
                </div>
                <div className="body-small text-text-secondary">
                  Protocol: <span className="text-primary font-medium">{inverter.protocol}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* System Architecture */}
        {content.architecture && content.architecture.length > 0 && (
          <div className="mb-20">
            <h3 className="heading-3 text-center mb-12">
              System <span className="text-primary">Architecture</span>
            </h3>
            
            <div className="space-y-4">
              {content.architecture.filter(layer => layer.enabled).map((layer, index) => {
                const Icon = iconMap[layer.icon] || Network
                return (
                  <motion.div
                    key={layer.id}
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="card hover:border-primary/40"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
                      <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4 self-start sm:self-center flex-shrink-0">
                        <Icon className="text-primary" size={28} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="heading-4 mb-3">{layer.layer}</h4>
                        <div className="flex flex-wrap gap-2">
                          {layer.components.map((component, compIndex) => (
                            <span
                              key={compIndex}
                              className="px-3 py-2 bg-dark-tertiary rounded-full body-small text-text-secondary border border-dark-border hover:border-primary/30 transition-colors whitespace-nowrap"
                            >
                              {component}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </div>
        )}

        {/* Network Ports & Services */}
        {content.networkPorts && content.networkPorts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="card-elevated bg-primary/5 border-primary/20"
          >
            <h3 className="heading-4 mb-6">Network Ports & Services</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {content.networkPorts.filter(port => port.enabled).map((port) => (
                <div key={port.id} className="space-y-2">
                  <div className="code-inline">{port.port}</div>
                  <div className="body-small text-text-secondary">{port.description}</div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </section>
  )
}