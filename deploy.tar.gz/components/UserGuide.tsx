'use client'

import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { Rocket, Settings, Zap, Brain, Database, Bell, Target, Shield, BarChart, Battery, Lightbulb } from 'lucide-react'
import { getUserGuideContent, UserGuideContent } from '@/lib/admin'

const iconMap: Record<string, any> = {
  rocket: Rocket,
  settings: Settings,
  zap: Zap,
  brain: Brain,
  database: Database,
  bell: Bell,
  target: Target,
  shield: Shield,
  'bar-chart': BarChart,
  battery: Battery
}

export default function UserGuide() {
  const [content, setContent] = useState<UserGuideContent>({ title: "", subtitle: "", sections: [], proTips: [] })

  useEffect(() => {
    getUserGuideContent().then(setContent)
  }, [])


  const enabledSections = content.sections.filter(s => s.enabled)
  const enabledTips = content.proTips.filter(t => t.enabled)

  return (
    <section id="user-guide" className="section-padding bg-dark">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="heading-2 mb-6" dangerouslySetInnerHTML={{ __html: content.title }} />
          <p className="body-large text-text-secondary max-w-4xl mx-auto">{content.subtitle}</p>
        </motion.div>

        <div className="space-y-12">
          {enabledSections.map((section, index) => {
            const Icon = iconMap[section.icon] || Settings
            return (
              <motion.div
                key={section.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="card-elevated"
              >
                <div className="flex items-start space-x-4 mb-6">
                  <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4 flex-shrink-0">
                    <Icon className="text-primary" size={28} />
                  </div>
                  <div>
                    <h3 className="heading-3 mb-2">{section.title}</h3>
                    <p className="body-base text-text-secondary">{section.description}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {section.subsections.map((subsection, subIndex) => (
                    <div key={subIndex} className="card bg-dark-tertiary">
                      <h4 className="heading-4 mb-4">{subsection.title}</h4>
                      <div className="space-y-3">
                        {subsection.steps.map((step, stepIndex) => (
                          <div key={stepIndex} className="flex items-start space-x-3">
                            <div className="bg-primary/20 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="text-primary text-xs font-bold">{stepIndex + 1}</span>
                            </div>
                            <p className="body-small text-text-secondary flex-1">{step}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )
          })}
        </div>

        {enabledTips.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="mt-16"
          >
            <div className="flex items-center space-x-3 mb-8">
              <Lightbulb className="text-primary" size={28} />
              <h3 className="heading-3">Pro Tips</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {enabledTips.map((tip) => {
                const TipIcon = iconMap[tip.icon] || BarChart
                return (
                  <div key={tip.id} className="card-interactive bg-primary/5 border-primary/20">
                    <TipIcon className="text-primary mb-4" size={24} />
                    <h4 className="heading-4 mb-3">{tip.title}</h4>
                    <p className="body-small text-text-secondary">{tip.description}</p>
                  </div>
                )
              })}
            </div>
          </motion.div>
        )}
      </div>
    </section>
  )
}
